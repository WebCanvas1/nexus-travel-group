import { Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';
import { Reveal } from '@/components/Reveal';
import { sectionImages } from '@/data/siteConfig';
import { siteConfig } from '@/data/siteConfig';
import { useNav } from '@/context/NavContext';

export function Contact() {
  const { openEnquiry } = useNav();

  return (
    <section id="contact" className="relative py-24 md:py-36 bg-charcoal-950">
      <div className="container-premium">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Info */}
          <div>
            <Reveal>
              <p className="eyebrow mb-4">Contact</p>
            </Reveal>
            <Reveal delay={1}>
              <h2 className="section-heading text-balance">
                Let's start{' '}
                <span className="italic text-ochre-300">talking.</span>
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <p className="mt-8 text-lg text-ivory-200/70 leading-relaxed max-w-md">
                Nexus Travel Group specialises in professionally organised tours and
                group travel experiences across Sydney and the Central Coast. From
                relaxed day trips to extended adventures, school excursions, cruises
                and winery experiences, we make group travel simple, enjoyable and
                memorable.
              </p>
            </Reveal>

            <Reveal delay={3}>
              <div className="mt-10 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-charcoal-800 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-4 h-4 text-ochre-400" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-1">
                      Phone
                    </p>
                    <p className="text-ivory-200/80">
                      <a href={`tel:${siteConfig.phone.replace(/\s/g, '')}`} className="hover:text-ochre-400 transition-colors duration-300">
                        {siteConfig.phone}
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-charcoal-800 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-4 h-4 text-ochre-400" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-1">
                      Email
                    </p>
                    <p className="text-ivory-200/80">
                      <a href={`mailto:${siteConfig.email}`} className="hover:text-ochre-400 transition-colors duration-300">
                        {siteConfig.email}
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-charcoal-800 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-4 h-4 text-ochre-400" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-1">
                      Address
                    </p>
                    <p className="text-ivory-200/80">{siteConfig.address}</p>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={4}>
              <div className="mt-10 flex items-center gap-4">
                <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50">
                  Follow
                </p>
                <a
                  href={siteConfig.social.facebook}
                  className="w-10 h-10 rounded-full bg-charcoal-800 flex items-center justify-center hover:bg-ochre-500/20 transition-colors duration-300"
                  aria-label="Facebook"
                >
                  <Facebook className="w-4 h-4 text-ivory-200/70" />
                </a>
                <a
                  href={siteConfig.social.instagram}
                  className="w-10 h-10 rounded-full bg-charcoal-800 flex items-center justify-center hover:bg-ochre-500/20 transition-colors duration-300"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4 text-ivory-200/70" />
                </a>
              </div>
            </Reveal>

            <Reveal delay={5}>
              <button
                onClick={() => openEnquiry('Other / Custom Tour' as never)}
                className="btn-primary mt-10"
              >
                Send an Enquiry
              </button>
            </Reveal>
          </div>

          {/* Image */}
          <Reveal delay={2}>
            <div className="img-zoom overflow-hidden rounded-sm">
              <img
                src={sectionImages.contact}
                alt="Sydney skyline at sunset"
                className="w-full h-[400px] md:h-[560px] object-cover"
                loading="lazy"
              />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
