import { Reveal } from '@/components/Reveal';
import { sectionImages } from '@/data/siteConfig';
import { useNav } from '@/context/NavContext';

export function MultiDayJourneys() {
  const { openEnquiry } = useNav();

  const itineraryPreview = [
    { day: 'Day 01', title: 'Sydney → Destination', description: 'Depart Sydney or the Central Coast and begin the journey through NSW\'s changing landscapes.' },
    { day: 'Day 02', title: 'Destination Experience', description: 'Full day exploring the region — lookouts, local produce and hidden trails.' },
    { day: 'Day 03', title: 'Continue the Journey', description: 'Travel further into the landscape with new stops and stories along the way.' },
    { day: 'Day 04', title: 'Hidden Gems', description: 'Discover the places most travellers never reach, with time to truly explore.' },
    { day: 'Day 05', title: 'Return Journey', description: 'A scenic route home with one last unforgettable view.' },
  ];

  return (
    <section id="multi-day" className="relative py-24 md:py-36 bg-charcoal-900 overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 opacity-10">
        <img
          src={sectionImages.multiDayHero}
          alt=""
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>

      <div className="relative container-premium">
        {/* Header */}
        <div className="max-w-3xl mb-16 md:mb-20">
          <Reveal>
            <p className="eyebrow mb-4">Multi-Day Journeys</p>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="section-heading text-balance">
              More than a tour.{' '}
              <span className="italic text-ochre-300">A journey.</span>
            </h2>
          </Reveal>
          <Reveal delay={2}>
            <p className="mt-8 text-lg text-ivory-200/80 leading-relaxed">
              Our extended tours are carefully planned to take you beyond the
              day-trip. Multiple destinations, comfortable transport, and routes
              designed to showcase the very best of each region — without the rush.
            </p>
          </Reveal>
        </div>

        {/* Itinerary preview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          {/* Image */}
          <Reveal>
            <div className="img-zoom overflow-hidden rounded-sm sticky top-24">
              <img
                src={sectionImages.multiDayHero}
                alt="NSW regional landscape"
                className="w-full h-[500px] md:h-[600px] object-cover"
                loading="lazy"
              />
            </div>
          </Reveal>

          {/* Itinerary items */}
          <div>
            {itineraryPreview.map((item, i) => (
              <Reveal key={i} delay={(i % 3) + 1}>
                <div className="group flex gap-6 py-6 border-b border-ivory-200/5 last:border-b-0 hover:pl-2 transition-all duration-500 ease-premium">
                  <div className="flex-shrink-0 w-20">
                    <p className="font-display text-2xl font-light text-ochre-400/80 group-hover:text-ochre-400 transition-colors duration-300">
                      {item.day.split(' ')[1]}
                    </p>
                    <p className="text-[10px] uppercase tracking-[0.2em] text-ivory-300/40">
                      {item.day.split(' ')[0]}
                    </p>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display text-xl font-light text-ivory-50 mb-1 group-hover:text-ochre-300 transition-colors duration-300">
                      {item.title}
                    </h3>
                    <p className="text-sm text-ivory-200/60 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}

            <Reveal delay={3}>
              <div className="mt-10">
                <p className="text-sm text-ivory-200/60 mb-4">
                  Actual itineraries and dates will be added as journeys are scheduled.
                </p>
                <button
                  onClick={() => openEnquiry('Extended Tour' as never)}
                  className="btn-outline"
                >
                  Enquire About Journeys
                </button>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
