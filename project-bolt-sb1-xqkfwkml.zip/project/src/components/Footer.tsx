import { Facebook, Instagram, Phone, Mail, MapPin } from 'lucide-react';
import { siteConfig } from '@/data/siteConfig';
import { useNav } from '@/context/NavContext';

export function Footer() {
  const { navigate, openEnquiry } = useNav();

  const handleNav = (target: string) => {
    if (target === 'about') {
      navigate('about');
    } else {
      navigate('home');
      setTimeout(() => {
        const el = document.getElementById(target);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  return (
    <footer className="bg-charcoal-950 border-t border-ivory-200/5 pt-20 pb-10">
      <div className="container-premium">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-1">
            <h3 className="font-display text-2xl font-medium text-ivory-50 mb-2">
              NEXUS
            </h3>
            <p className="text-[10px] uppercase tracking-[0.3em] text-ochre-400 mb-6">
              Travel Group
            </p>
            <p className="font-display text-lg font-light text-ivory-200/70 italic leading-relaxed">
              Explore. Discover.
              <br />
              Experience Sydney & the Central Coast.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-6">
              Explore
            </p>
            <nav className="flex flex-col gap-3">
              {siteConfig.nav.map((item) => (
                <button
                  key={item.target}
                  onClick={() => handleNav(item.target)}
                  className="text-left text-sm text-ivory-200/70 hover:text-ochre-400 transition-colors duration-300"
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-6">
              Contact
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-ivory-200/70">
                <Phone className="w-3.5 h-3.5 text-ochre-400/60" />
                <a href={`tel:${siteConfig.phone.replace(/\s/g, '')}`} className="hover:text-ochre-400 transition-colors duration-300">
                  {siteConfig.phone}
                </a>
              </div>
              <div className="flex items-center gap-2 text-sm text-ivory-200/70">
                <Mail className="w-3.5 h-3.5 text-ochre-400/60" />
                <a href={`mailto:${siteConfig.email}`} className="hover:text-ochre-400 transition-colors duration-300">
                  {siteConfig.email}
                </a>
              </div>
              <div className="flex items-start gap-2 text-sm text-ivory-200/70">
                <MapPin className="w-3.5 h-3.5 text-ochre-400/60 mt-0.5" />
                {siteConfig.address}
              </div>
            </div>
            <div className="flex items-center gap-3 mt-6">
              <a
                href={siteConfig.social.facebook}
                className="w-9 h-9 rounded-full bg-charcoal-800 flex items-center justify-center hover:bg-ochre-500/20 transition-colors duration-300"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4 text-ivory-200/60" />
              </a>
              <a
                href={siteConfig.social.instagram}
                className="w-9 h-9 rounded-full bg-charcoal-800 flex items-center justify-center hover:bg-ochre-500/20 transition-colors duration-300"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4 text-ivory-200/60" />
              </a>
            </div>
          </div>

          {/* CTA */}
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-6">
              Ready to Travel?
            </p>
            <p className="text-sm text-ivory-200/70 mb-6 leading-relaxed">
              Tell us where you'd like to go and we'll take it from there.
            </p>
            <button
              onClick={() => openEnquiry('Other / Custom Tour' as never)}
              className="btn-primary !py-3 !px-6"
            >
              Enquire Now
            </button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-ivory-200/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ivory-300/40">
            © {new Date().getFullYear()} Nexus Travel Group. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <button className="text-xs text-ivory-300/40 hover:text-ochre-400 transition-colors duration-300">
              Privacy Policy
            </button>
            <button className="text-xs text-ivory-300/40 hover:text-ochre-400 transition-colors duration-300">
              Terms & Conditions
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
