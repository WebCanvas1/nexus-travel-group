import { Clock, MapPin, ArrowRight, Tag } from 'lucide-react';
import { Reveal } from '@/components/Reveal';
import { tours, type Tour, type EnquiryType } from '@/data/tours';
import { useNav } from '@/context/NavContext';

export function FeaturedTours() {
  const { openEnquiry } = useNav();

  const handleCardClick = (tour: Tour) => {
    openEnquiry(tour.typeName as EnquiryType, tour.id);
  };

  return (
    <section id="tours" className="relative py-24 md:py-36 bg-charcoal-950">
      <div className="container-premium">
        {/* Section header */}
        <div className="mb-16 md:mb-20 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <Reveal>
              <p className="eyebrow mb-4">Our Services</p>
            </Reveal>
            <Reveal delay={1}>
              <h2 className="section-heading text-balance">
                Specialising in group travel across{' '}
                <span className="italic text-ochre-300">Sydney & the Central Coast.</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={2}>
            <p className="text-ivory-200/70 max-w-sm text-sm md:text-base">
              From day tours and school groups to winery experiences and cruises,
              we make group travel simple, enjoyable and memorable.
            </p>
          </Reveal>
        </div>

        {/* Tour cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {tours.map((tour, i) => (
            <Reveal key={tour.id} delay={(i % 3) + 1}>
              <article
                onClick={() => handleCardClick(tour)}
                className="group relative bg-charcoal-900 overflow-hidden rounded-sm border border-ivory-200/5 hover:border-ochre-400/20 transition-all duration-700 ease-premium cursor-pointer h-full flex flex-col"
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden img-zoom">
                  <img
                    src={tour.image}
                    alt={tour.name}
                    className="w-full h-full object-cover transition-transform duration-[1.2s] ease-premium group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-card opacity-60" />
                  {/* Tour type badge */}
                  <div className="absolute top-4 left-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-charcoal-950/80 backdrop-blur-sm text-[10px] uppercase tracking-[0.2em] text-ochre-400 rounded-sm">
                      <Tag className="w-3 h-3" />
                      {tour.typeName}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex flex-col flex-1">
                  {/* Meta */}
                  <div className="flex items-center gap-4 mb-3 text-xs text-ivory-300/60">
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5" />
                      {tour.destination}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {tour.duration}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-display text-2xl font-light text-ivory-50 mb-3 group-hover:text-ochre-300 transition-colors duration-300">
                    {tour.name}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-ivory-200/70 leading-relaxed line-clamp-3 mb-5 flex-1">
                    {tour.description}
                  </p>

                  {/* CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-ivory-200/5">
                    <span className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.15em] text-ochre-400 group-hover:text-ochre-300 transition-colors duration-300">
                      Enquire About This Tour
                      <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
