import { Clock, MapPin, Check, ArrowLeft, Info, Calendar, Users } from 'lucide-react';
import { Reveal } from '@/components/Reveal';
import { tours, type Tour } from '@/data/tours';
import { useNav } from '@/context/NavContext';
import type { EnquiryType } from '@/data/tours';

interface TourDetailProps {
  tourId: string;
}

export function TourDetail({ tourId }: TourDetailProps) {
  const { navigate, openEnquiry } = useNav();
  const tour = tours.find((t) => t.id === tourId);

  if (!tour) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-charcoal-950">
        <div className="text-center">
          <p className="text-ivory-200 mb-4">Tour not found.</p>
          <button onClick={() => navigate('home')} className="btn-outline">
            Return Home
          </button>
        </div>
      </div>
    );
  }

  const handleBack = () => {
    navigate('home');
    setTimeout(() => {
      const el = document.getElementById('tours');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleEnquire = () => {
    const type = tour.typeName as EnquiryType;
    openEnquiry(type, tour.id);
  };

  return (
    <div className="bg-charcoal-950">
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[500px] w-full overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={tour.image}
            alt={tour.name}
            className="w-full h-full object-cover animate-slow-zoom"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-hero" />

        <div className="relative h-full flex flex-col justify-end container-premium pb-16">
          <button
            onClick={handleBack}
            className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.15em] text-ivory-200/80 hover:text-ochre-400 transition-colors mb-8 self-start"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Tours
          </button>

          <div className="flex flex-wrap items-center gap-4 mb-4">
            <span className="px-3 py-1.5 bg-ochre-500/20 backdrop-blur-sm text-[10px] uppercase tracking-[0.2em] text-ochre-300 rounded-sm">
              {tour.typeName}
            </span>
            <span className="flex items-center gap-1.5 text-sm text-ivory-200/80">
              <MapPin className="w-4 h-4" /> {tour.destination}
            </span>
            <span className="flex items-center gap-1.5 text-sm text-ivory-200/80">
              <Clock className="w-4 h-4" /> {tour.duration}
            </span>
          </div>

          <h1 className="font-display text-display-md md:text-display-lg font-light text-ivory-50 text-shadow-cinematic max-w-3xl">
            {tour.name}
          </h1>
        </div>
      </section>

      {/* Overview */}
      <section className="py-20 md:py-28">
        <div className="container-premium">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16">
            <div className="lg:col-span-2">
              <Reveal>
                <p className="eyebrow mb-4">Overview</p>
              </Reveal>
              <Reveal delay={1}>
                <p className="text-lg md:text-xl text-ivory-200/80 leading-relaxed">
                  {tour.longDescription}
                </p>
              </Reveal>
            </div>

            {/* Quick facts */}
            <Reveal delay={2}>
              <div className="bg-charcoal-900 border border-ivory-200/5 rounded-sm p-6 space-y-4">
                <h3 className="text-xs uppercase tracking-[0.2em] text-ochre-400 mb-4">
                  Tour Details
                </h3>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-ivory-300/60 mt-0.5" />
                  <div>
                    <p className="text-xs text-ivory-300/50 uppercase tracking-wide">Duration</p>
                    <p className="text-ivory-100">{tour.duration}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-ivory-300/60 mt-0.5" />
                  <div>
                    <p className="text-xs text-ivory-300/50 uppercase tracking-wide">Destination</p>
                    <p className="text-ivory-100">{tour.destination}</p>
                  </div>
                </div>
                {tour.priceFrom && (
                  <div className="flex items-start gap-3">
                    <Tag className="w-5 h-5 text-ivory-300/60 mt-0.5" />
                    <div>
                      <p className="text-xs text-ivory-300/50 uppercase tracking-wide">Price</p>
                      <p className="text-ivory-100">{tour.priceFrom}</p>
                    </div>
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-ivory-300/60 mt-0.5" />
                  <div>
                    <p className="text-xs text-ivory-300/50 uppercase tracking-wide">Type</p>
                    <p className="text-ivory-100">{tour.typeName}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="py-20 bg-charcoal-900">
        <div className="container-premium">
          <Reveal>
            <p className="eyebrow mb-4">Highlights</p>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="font-display text-3xl md:text-4xl font-light text-ivory-50 mb-12">
              What you'll experience
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tour.highlights.map((highlight, i) => (
              <Reveal key={highlight} delay={(i % 2) + 1}>
                <div className="flex items-start gap-4 p-5 bg-charcoal-800 rounded-sm border border-ivory-200/5 hover:border-ochre-400/20 transition-colors duration-500">
                  <Check className="w-5 h-5 text-ochre-400 mt-0.5 flex-shrink-0" />
                  <p className="text-ivory-200/80">{highlight}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Itinerary */}
      {tour.itinerary.length > 0 && (
        <section className="py-20 md:py-28">
          <div className="container-premium">
            <Reveal>
              <p className="eyebrow mb-4">Itinerary</p>
            </Reveal>
            <Reveal delay={1}>
              <h2 className="font-display text-3xl md:text-4xl font-light text-ivory-50 mb-12">
                Day by day
              </h2>
            </Reveal>

            <div className="relative">
              {/* Vertical line */}
              <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-ivory-200/10 md:-translate-x-1/2" />

              {tour.itinerary.map((item, i) => (
                <Reveal key={i} delay={(i % 2) + 1}>
                  <div
                    className={`relative flex flex-col md:flex-row gap-6 mb-8 ${
                      i % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                    }`}
                  >
                    {/* Dot */}
                    <div className="absolute left-0 md:left-1/2 top-2 w-3 h-3 rounded-full bg-ochre-500 md:-translate-x-1/2 ring-4 ring-charcoal-950 z-10" />

                    {/* Content */}
                    <div className="pl-8 md:pl-0 md:w-1/2 md:px-8">
                      <div className="bg-charcoal-900 border border-ivory-200/5 rounded-sm p-6 hover:border-ochre-400/20 transition-colors duration-500">
                        <p className="text-xs uppercase tracking-[0.2em] text-ochre-400 mb-2">
                          {item.day}
                        </p>
                        <h3 className="font-display text-xl font-light text-ivory-50 mb-2">
                          {item.title}
                        </h3>
                        <p className="text-sm text-ivory-200/70 leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                    {/* Spacer */}
                    <div className="hidden md:block md:w-1/2" />
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* What's Included */}
      <section className="py-20 bg-charcoal-900">
        <div className="container-premium">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <Reveal>
                <p className="eyebrow mb-4">What's Included</p>
              </Reveal>
              <Reveal delay={1}>
                <div className="space-y-3 mt-6">
                  {tour.included.map((item) => (
                    <div key={item} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-eucalyptus-400 mt-0.5 flex-shrink-0" />
                      <p className="text-ivory-200/80">{item}</p>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>

            <div>
              <Reveal delay={2}>
                <p className="eyebrow mb-4">Good to Know</p>
              </Reveal>
              <Reveal delay={3}>
                <div className="space-y-6 mt-6">
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-2">
                      Pickup Information
                    </p>
                    <p className="text-ivory-200/80 text-sm leading-relaxed">
                      {tour.pickupInfo}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-ivory-300/50 mb-2">
                      Additional Information
                    </p>
                    <p className="text-ivory-200/80 text-sm leading-relaxed">
                      {tour.additionalInfo}
                    </p>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      {tour.gallery.length > 0 && (
        <section className="py-20 md:py-28">
          <div className="container-premium">
            <Reveal>
              <p className="eyebrow mb-4">Gallery</p>
            </Reveal>
            <Reveal delay={1}>
              <h2 className="font-display text-3xl md:text-4xl font-light text-ivory-50 mb-12">
                A glimpse of the journey
              </h2>
            </Reveal>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {tour.gallery.map((img, i) => (
                <Reveal key={i} delay={(i % 4) + 1}>
                  <div className="img-zoom overflow-hidden rounded-sm aspect-square">
                    <img
                      src={img}
                      alt={`${tour.name} gallery image ${i + 1}`}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Enquiry CTA */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={tour.gallery[0] || tour.image}
            alt=""
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-charcoal-950/85" />
        </div>
        <div className="relative container-premium text-center">
          <Reveal>
            <p className="eyebrow mb-4">Interested in this tour?</p>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="font-display text-display-md font-light text-ivory-50 text-balance max-w-2xl mx-auto">
              Send us an enquiry and we'll contact you with availability and further
              information.
            </h2>
          </Reveal>
          <Reveal delay={2}>
            <button onClick={handleEnquire} className="btn-primary mt-10">
              Enquire About This Tour
            </button>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
