import { Check, ArrowRight } from 'lucide-react';
import { Reveal } from '@/components/Reveal';
import { sectionImages } from '@/data/siteConfig';
import { useNav } from '@/context/NavContext';

export function SchoolGroupCharters() {
  const { openEnquiry } = useNav();

  const uses = [
    'School excursions',
    'Educational trips',
    'School camps',
    'Sporting events',
    'Group excursions',
    'Private group travel',
    'Custom itineraries',
  ];

  return (
    <section id="charters" className="relative py-24 md:py-36 bg-charcoal-950">
      <div className="container-premium">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div className="relative">
            <Reveal>
              <div className="img-zoom relative overflow-hidden rounded-sm">
                <img
                  src={sectionImages.charter}
                  alt="School group on an outdoor excursion"
                  className="w-full h-[400px] md:h-[560px] object-cover"
                  loading="lazy"
                />
              </div>
            </Reveal>
            {/* Secondary image */}
            <Reveal delay={2}>
              <div className="absolute -bottom-10 -right-4 md:-right-10 w-40 md:w-52 img-zoom overflow-hidden rounded-sm border-4 border-charcoal-950 shadow-2xl hidden sm:block">
                <img
                  src={sectionImages.charterSecondary}
                  alt="Premium tour coach"
                  className="w-full h-28 md:h-36 object-cover"
                  loading="lazy"
                />
              </div>
            </Reveal>
          </div>

          {/* Content */}
          <div>
            <Reveal>
              <p className="eyebrow mb-4">School & Group Charters</p>
            </Reveal>
            <Reveal delay={1}>
              <h2 className="section-heading text-balance">
                Travel together.{' '}
                <span className="italic text-ochre-300">Arrive together.</span>
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <p className="mt-8 text-lg text-ivory-200/80 leading-relaxed">
                Flexible charter solutions for schools, educational groups,
                organisations, clubs and private groups across Sydney and the
                Central Coast. We handle the logistics so you can focus on the
                experience.
              </p>
            </Reveal>

            <Reveal delay={3}>
              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {uses.map((use) => (
                  <div key={use} className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-ochre-400 flex-shrink-0" />
                    <span className="text-sm text-ivory-200/80">{use}</span>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={4}>
              <button
                onClick={() => openEnquiry('School Group Tour' as never)}
                className="btn-primary mt-10"
              >
                Plan Your Group Trip
                <ArrowRight className="w-4 h-4" />
              </button>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
