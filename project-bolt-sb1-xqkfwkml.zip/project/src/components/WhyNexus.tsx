import { Heart, Map, Users, Sparkles, Compass } from 'lucide-react';
import { Reveal } from '@/components/Reveal';

export function WhyNexus() {
  const points = [
    {
      icon: Heart,
      title: 'Personally Managed',
      description:
        'Every enquiry is handled personally. No call centres, no automated responses — just real people who care about your journey.',
    },
    {
      icon: Map,
      title: 'Sydney & Central Coast Specialists',
      description:
        'Based in NSW, we know the roads, the regions and the hidden gems across Sydney and the Central Coast that make each journey memorable.',
    },
    {
      icon: Users,
      title: 'Flexible Group Travel',
      description:
        'From intimate day tours to large group charters, we tailor every journey to suit the needs of your group.',
    },
    {
      icon: Compass,
      title: 'Memorable Destinations',
      description:
        'Carefully curated routes through some of NSW\'s most spectacular landscapes — coastlines, waterways, regional towns and hidden gems.',
    },
    {
      icon: Sparkles,
      title: 'Friendly Personal Service',
      description:
        'We treat every traveller like a guest, not a booking. Your comfort and experience come first, always.',
    },
  ];

  return (
    <section className="relative py-24 md:py-36 bg-charcoal-950">
      <div className="container-premium">
        {/* Header */}
        <div className="max-w-3xl mb-16 md:mb-20">
          <Reveal>
            <p className="eyebrow mb-4">Why Nexus</p>
          </Reveal>
          <Reveal delay={1}>
            <h2 className="section-heading text-balance">
              Travel should be{' '}
              <span className="italic text-ochre-300">personal.</span>
            </h2>
          </Reveal>
          <Reveal delay={2}>
            <p className="mt-6 text-lg text-ivory-200/70 leading-relaxed">
              We're not a booking platform. We're a travel partner — here to make
              sure every journey is as memorable as the destination.
            </p>
          </Reveal>
        </div>

        {/* Points - editorial layout, not generic cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-ivory-200/5">
          {points.map((point, i) => {
            const Icon = point.icon;
            return (
              <Reveal key={point.title} delay={(i % 3) + 1}>
                <div className="group h-full bg-charcoal-950 p-8 md:p-10 hover:bg-charcoal-900 transition-colors duration-700 ease-premium">
                  <Icon className="w-7 h-7 text-ochre-400 mb-6 transition-transform duration-500 group-hover:scale-110" />
                  <h3 className="font-display text-2xl font-light text-ivory-50 mb-3">
                    {point.title}
                  </h3>
                  <p className="text-sm text-ivory-200/70 leading-relaxed">
                    {point.description}
                  </p>
                </div>
              </Reveal>
            );
          })}

          {/* Final cell - CTA */}
          <Reveal delay={3}>
            <div className="h-full bg-ochre-950/30 p-8 md:p-10 flex flex-col justify-center border-l border-ochre-400/10">
              <p className="font-display text-2xl font-light text-ivory-50 mb-3">
                Ready to begin?
              </p>
              <p className="text-sm text-ivory-200/70 mb-6">
                Tell us where you'd like to go and we'll take it from there.
              </p>
              <button
                onClick={() => {
                  const el = document.getElementById('enquiry');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-sm uppercase tracking-[0.15em] text-ochre-400 hover:text-ochre-300 transition-colors duration-300 self-start"
              >
                Start your enquiry
                <span className="text-lg">→</span>
              </button>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
